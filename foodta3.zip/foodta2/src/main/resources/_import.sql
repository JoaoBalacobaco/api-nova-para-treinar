insert into tb_cozinha(nome_cozinha) values ('Brasileira');
insert into tb_cozinha(nome_cozinha) values ('Italiana');
insert into tb_cozinha(nome_cozinha) values ('Mexicana');

insert into tb_restaurante(nome, taxa_frete, cozinha_id) values ("Bidu", 10.00, 1);
insert into tb_restaurante(nome, taxa_frete, cozinha_id) values ("Seu Jorge", 12.00, 2);
insert into tb_restaurante(nome, taxa_frete, cozinha_id) values ("Madre Mexicana", 5.00, 3);

insert into tb_cidade(nome, estado_id) values ("Lençóis Paulista", 1);
insert into tb_cidade(nome, estado_id) values ("Balneário Camburiú", 2);
insert into tb_cidade(nome, estado_id) values ("Rio de Janeiro", 3);