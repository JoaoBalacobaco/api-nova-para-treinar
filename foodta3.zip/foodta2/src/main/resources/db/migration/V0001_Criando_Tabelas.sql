create table tb_cozinhas (
    id bigint not null auto_increment,
    nome_cozinha varchar(70),

    primary key(id)
) engine=InnoDB default charset=utf8;

create table tb_restaurante (
    id bigint not null auto_increment,
    nome

    primary key(id)
) engine=InnoDB default charset=utf8;

create table tb_estado (
    id bigint not null auto_increment,
    nome_estado char(2),

    primary key(id)
) engine=InnoDB default charset=utf8;

create table tb_cidade(
    id bigint not null auto_increment,
    nome varchar(100)
    estado bigint,

    primary key(id, estado)
)engine=InnoDB default charset=utf8;

create table grupo(
    id bigint not null auto_increment,
    nome varchar(60) not null,

    primary key (id)
)engine=InnoDB default charset=utf8;

create table grupo_permissao(
    grupo_id bigint not null,
    permissao_id bigint not null,

    primary key (grupo_id , permissao_id)
) engine=InnoDB default charset=utf8;

create table permissao(
    id big int not null auto_increment,
    descricao varchar(60) not null,
    nome varchar(100) not null,

    primary key (id)
)engine=InnoDB default charset=utf8;

create table produto (
    id bigint not null auto_increment,

)engine=InnoDB default charset=utf8;

create table tb_restaurante(
    id bigint not null auto_increment,
    cozinha_id bigint not null,
    nome varchar(100),
    taxaFrete decimal(10,2),
    data_autualizacao datetime not null,
    data_cadastro datetime not null,

    endereco_cidade bigint,
    endereco_cep varchar(9),
    endereco_loradouro varchar(100),
    endereco_numero varchar(20),
    endereco_completo varchar (60),
    endereco_bairro varchar(60),

primary key(id)
)engine=InnoDB default charset=utf8;

create table restaurante_forma_pagamento(
    restaurante_id bigint not null,
    forma_pagamento_id not null,

    primary (restaurante_id , forma_pagamento_id)
)engine=InnoDB default charset=utf8;

create table usuario (
    id bigint not null auto_increment,
    nome varchar(80) not null,
    email varchar(255) not null,
    senha varchar(255) not null,
    data_cadastro datetime not null,

    primary key(id)
)engine=InnoDB default charset=utf8;

create table usuario_grupo(
    usuario_id bigint not null,
    gurpo_id bigint not null,

    primary key (usuario_id, grupo_id)
)engine=InnoDB default charset=utf8;

alter table tb_cidade add constraint fk_estado_cidade foreign key references tb_estado(id);
alter table tb_restaurante add constraint fk_cozinha_restaurante foreign key references tb_cozinha(id);
alter table grupo_permissao add constraint fk_grupo_permissao_permissao foreign key (permissao_id) references permissao (id);
alter table grupo_permissao add constraint fk_grupo_permissao_grupo foreign key (grupo_id) references (grupo_id);
alter table produto add constraint fk_produto_tb_restaurante foreign key (cozinha_id) references tb_cozinha(id);
alter table tb_restaurante add constraint fk_tb_restaurante_tb_cidade foreign key (endereco_cidade) references tb_cidade(id);
alter table restaurante_forma_pagamento add constraint fk_restaurante_forma_pagamento_forma_pagamento foreign key (forma_pagamento_id) references forma_pagamento(id);
alter table restaurante_forma_pagamento add constraint fk_restaurante_forma_pagamento_tb_restaurante foreign key (restaurante_id) references tb_restaurante (id);
alter table usuario_grupo add constraint fk_usuario_fk_grupo_grupo foreign key (grupo_id) references grupo (id);
alter table usuario_grupo add constraint fk_usuario_grupo_usuario foreign key (usuario_id) references usuario (id);