CREATE TABLE tb_cozinha(
    id bigint not null auto_increment,
    nome_cozinha varchar(70),

    primary key(id)
)engine=InnoDB default charset=utf8;
CREATE TABLE tb_cidade(
    id bigint not null auto_increment,
    nome varchar(244),
)