package com.gabrielv.foodta.domain.service;

import com.gabrielv.foodta.domain.exception.EntidadeEmUsoException;
import com.gabrielv.foodta.domain.exception.EntidadeNaoEncontradaException;
import com.gabrielv.foodta.domain.model.Cozinha;
import com.gabrielv.foodta.domain.model.Restaurante;
import com.gabrielv.foodta.domain.repository.RestauranteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class RestauranteService {
    @Autowired
    private RestauranteRepository restauranteRepository;

    public Restaurante salvar(Restaurante restaurante) { return restauranteRepository.save(restaurante); }

    public void excluir(Long id) {
        try {
            restauranteRepository.deleteById(id);
        }
        catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(String.format("Restaurante ou código %d não pode ser removido, pois está em uso.", id));
        }

        catch (EmptyResultDataAccessException e) {
            throw new EntidadeNaoEncontradaException(String.format("Não existe cadastro de restaurante com código %d", id));
        }
    }
}
